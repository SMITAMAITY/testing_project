const{ 
    createPool
} = require('mysql');

const Pool = createPool({
    host: "localhost",
    user:"root",
    password:"Silvershine@1996",
    database:"Test",
    connectionLimit:10
});

Pool.query(`select * from Table1`,(err,result,fields)=>
{
    if(err){
        console.log(err);
    }
    //return console.log(result);
    return console.log('Connected');
})

module.exports = Pool;
